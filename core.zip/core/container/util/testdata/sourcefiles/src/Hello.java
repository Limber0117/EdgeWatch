/*
Copyright IBM Corp. All Rights Reserved.

SPDX-License-Identifier: Apache-2.0
 */

public class Hello {
    public static void main(String []args) {
        System.out.println("Hello");
        System.exit(0);
    }
}
